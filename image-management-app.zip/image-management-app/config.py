DATABASE_URI = "mongodb+srv://messias:<db_password>@clusterapi.gnrdo.mongodb.net/?retryWrites=true&w=majority&appName=Clusterapi"
SECRET_KEY = "messias"
UPLOAD_FOLDER = "uploads/"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "bmp", "webp"}