# Image Management App

This project is a simple image management application built with Python and Flask, utilizing MongoDB for storing image metadata. The application allows users to upload and delete images.

## Project Structure

```
image-management-app
├── app
│   ├── __init__.py
│   ├── main.py
│   ├── models.py
│   ├── routes.py
│   └── utils
│       └── image_handler.py
├── requirements.txt
├── config.py
├── .env
└── README.md
```

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd image-management-app
   ```

2. **Create a virtual environment:**
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install dependencies:**
   ```
   pip install -r requirements.txt
   ```

4. **Configure environment variables:**
   Create a `.env` file in the root directory and add your MongoDB connection string and any other necessary environment variables.

5. **Run the application:**
   ```
   python app/main.py
   ```

## Usage

- **Upload an Image:**
  Send a POST request to `/upload` with the image file.

- **Delete an Image:**
  Send a DELETE request to `/delete/<image_id>` to remove an image by its ID.

## Dependencies

- Flask
- PyMongo
- Other necessary libraries listed in `requirements.txt`

## License

This project is licensed under the MIT License.