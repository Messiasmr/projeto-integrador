from flask import Flask
from flask_pymongo import PyMongo
import os

app = Flask(__name__)

# Load configuration from environment variables
app.config["MONGO_URI"] = os.getenv("MONGO_URI")

mongo = PyMongo(app)

from app.routes import *

if __name__ == "__main__":
    app.run(debug=True)