from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
from pymongo import MongoClient
import os

# Initialize Flask Blueprint
image_bp = Blueprint('image_bp', __name__)

# MongoDB configuration
client = MongoClient(os.getenv('MONGODB_URI'))
db = client['image_management']
images_collection = db['images']

# Route for uploading an image
@image_bp.route('/upload', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    filename = secure_filename(file.filename)
    file.save(os.path.join('uploads', filename))
    
    # Save image metadata to MongoDB
    images_collection.insert_one({'filename': filename})
    
    return jsonify({'message': 'Image uploaded successfully', 'filename': filename}), 201

# Route for deleting an image
@image_bp.route('/delete/<filename>', methods=['DELETE'])
def delete_image(filename):
    result = images_collection.find_one_and_delete({'filename': filename})
    if result:
        os.remove(os.path.join('uploads', filename))
        return jsonify({'message': 'Image deleted successfully'}), 200
    else:
        return jsonify({'error': 'Image not found'}), 404