from mongoengine import Document, StringField, DateTimeField, FileField
from datetime import datetime

class Image(Document):
    title = StringField(required=True)
    description = StringField()
    upload_date = DateTimeField(default=datetime.utcnow)
    image_file = FileField()  # This will store the image file in MongoDB
    # Additional fields can be added as needed, such as tags or user information.