from flask import request
from werkzeug.utils import secure_filename
import os
from pymongo import MongoClient

client = MongoClient(os.getenv('MONGODB_URI'))
db = client['image_management']
images_collection = db['images']

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', "bmp", "webp"}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def upload_image(file):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join('uploads', filename)
        file.save(file_path)
        
        image_data = {
            'filename': filename,
            'path': file_path
        }
        images_collection.insert_one(image_data)
        return image_data
    return None

def delete_image(filename):
    image_data = images_collection.find_one({'filename': filename})
    if image_data:
        os.remove(image_data['path'])
        images_collection.delete_one({'filename': filename})
        return True
    return False